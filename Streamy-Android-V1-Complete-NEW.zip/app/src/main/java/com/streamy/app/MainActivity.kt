package com.streamy.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri

private val Background = Color(0xFF090A0F)
private val Surface = Color(0xFF151821)
private val Surface2 = Color(0xFF10131B)
private val Muted = Color(0xFF9AA0B2)
private val Purple = Color(0xFF8B3DFF)
private val Pink = Color(0xFFFF3FB4)
private val Orange = Color(0xFFFF8A3D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StreamyApp(this) }
    }
}

@Composable
private fun StreamyApp(context: Context) {
    var url by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = Surface,
            surfaceVariant = Surface2,
            primary = Purple,
            secondary = Pink,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D0F16)) {
                    val items = listOf(
                        "Home" to Icons.Default.Home,
                        "Downloads" to Icons.Default.Download,
                        "History" to Icons.Default.History,
                        "Me" to Icons.Default.Person
                    )
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(
                    url = url,
                    onUrlChange = { url = it },
                    onDownload = {
                        if (isHttpUrl(url)) {
                            enqueueDownload(context, url)
                        } else {
                            toast(context, "Paste a direct HTTP/HTTPS media URL.")
                        }
                    },
                    modifier = Modifier.padding(padding)
                )
                else -> PlaceholderScreen(
                    title = listOf("Home", "Downloads", "History", "Me")[tab],
                    modifier = Modifier.padding(padding)
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    url: String,
    onUrlChange: (String) -> Unit,
    onDownload: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(listOf(Orange, Pink, Purple)),
                        RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Download,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            Column {
                Text("Streamy", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Save what you love.", color = Muted, fontSize = 12.sp)
            }

            Spacer(Modifier.weight(1f))

            IconButton(onClick = {}) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Paste a downloadable link",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = onUrlChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text("https://…", color = Muted)
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Link, contentDescription = null)
                    },
                    trailingIcon = {
                        if (url.isNotBlank()) {
                            IconButton(onClick = { onUrlChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
            }
        }

        Button(
            onClick = onDownload,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) {
            Icon(Icons.Default.Download, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Download", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard(
                title = "Audio",
                subtitle = "MP3 / audio files",
                icon = Icons.Default.MusicNote,
                modifier = Modifier.weight(1f)
            )
            FeatureCard(
                title = "Video",
                subtitle = "MP4 / video files",
                icon = Icons.Default.PlayArrow,
                modifier = Modifier.weight(1f)
            )
        }

        Text("Simple & safe", fontSize = 19.sp, fontWeight = FontWeight.Bold)

        InfoRow(Icons.Default.Link, "Paste", "Use a media link from a source that permits downloads.")
        InfoRow(Icons.Default.Download, "Download", "Streamy saves the permitted file to Downloads.")
        InfoRow(Icons.Default.Folder, "Find it", "Open the Downloads tab or your phone's Files app.")

        Spacer(Modifier.height(8.dp))

        Text(
            "V1 does not bypass DRM or rip protected YouTube/Spotify streams.",
            color = Muted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun FeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        colors = CardDefaults.cardColors(containerColor = Surface)
    ) {
        Column(
            Modifier.fillMaxSize().padding(15.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = Pink, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun InfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .background(Purple.copy(alpha = 0.16f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Purple, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.Download,
                contentDescription = null,
                tint = Purple,
                modifier = Modifier.size(52.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("This section is prepared for V2.", color = Muted)
        }
    }
}

private fun isHttpUrl(value: String): Boolean {
    return try {
        val uri = value.trim().toUri()
        uri.scheme == "http" || uri.scheme == "https"
    } catch (_: Exception) {
        false
    }
}

private fun enqueueDownload(context: Context, value: String) {
    val request = DownloadManager.Request(Uri.parse(value))
        .setTitle("Streamy download")
        .setDescription("Downloading permitted media")
        .setNotificationVisibility(
            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
        )
        .setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOWNLOADS,
            "streamy_${System.currentTimeMillis()}"
        )

    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    manager.enqueue(request)
    toast(context, "Download started.")
}

private fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}
